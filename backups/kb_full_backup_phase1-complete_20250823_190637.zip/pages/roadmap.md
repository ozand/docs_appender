# Tactical Sprint Plan (sprint-plan.md)

## Sprint 1: Foundation & Simplification

**Цель:** Выполнить все задачи из эпика `EPIC-REFACTOR`, чтобы создать чистую кодовую базу без избыточной функциональности.

| Задача | ID Истории | Описание | Оценка (дни) |
| :--- | :--- | :--- | :--- |
| **Удаление аутентификации (Backend)** | | | **1.0** |
| Удалить модули аутентификации | US-001 | Удалить файлы `backend/src/backend/auth.py` и `backend/src/backend/models.py`. | 0.2 |
| Очистить `main.py` | US-001 | В `backend/src/backend/main.py` убрать все эндпоинты `/auth/*`, удалить зависимость `Depends(get_current_active_user)` из эндпоинтов `/combine/` и `/combine-folder/`, а также связанные импорты. | 0.4 |
| Обновить зависимости | US-001 | В `backend/pyproject.toml` удалить зависимости: `python-jose[cryptography]`, `passlib[bcrypt]`, `email-validator`. Выполнить `uv sync`. | 0.2 |
| Обновить тесты | US-001 | Удалить тесты, связанные с аутентификацией, из `backend/tests/` (например, `test_authentication.py`). Обновить `conftest.py`. | 0.2 |
| **Удаление аутентификации (Frontend)** | | | **1.0** |
| Удалить модуль аутентификации | US-002 | Удалить файл `frontend/src/frontend/auth.py`. | 0.2 |
| Очистить `app.py` | US-002 | В `frontend/app.py` удалить всю логику `AuthManager`, форму входа, проверку `is_authenticated()` и передачу `headers` в `requests`. Вернуть приложение к состоянию прямого анонимного доступа. | 0.6 |
| Обновить тесты | US-002 | Удалить E2E тесты, проверяющие логику входа, из `frontend/tests/e2e/`. | 0.2 |
| **Унификация и очистка** | | | **1.0** |
| Унифицировать скрипты запуска | US-003 | Создать в корне проекта единый скрипт `run.bat` / `run.sh`, который запускает бэкенд и фронтенд. Удалить дублирующиеся скрипты из `scripts/development/`. | 0.5 |
| Удалить устаревшие артефакты | US-004 | Удалить файл `frontend/app_old.py`. Удалить все избыточные файлы-отчеты (`PROJECT_COMPLETE*.md`, `FINAL_*.md` и т.д.) из `pages/`. | 0.5 |